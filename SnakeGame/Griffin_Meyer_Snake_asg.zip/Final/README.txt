Controls:
Arrow Keys to move.
Depending on direction snake will change colors, only eat the matching food color to grow. 
If you eat the wrong color you will shrink.
Shrinking to 0 will end the game. 
Hitting yourself will end the game.
Hitting the edge will end the game.
Score is displayed in the bottom left corner.

/!\REMEMBER/!\
If you die in the game you die in real life.